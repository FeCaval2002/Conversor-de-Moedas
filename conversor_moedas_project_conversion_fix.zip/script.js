document.addEventListener("DOMContentLoaded", () => {
  const API_URL = "https://your-backend-url.com"; // URL do back-end hospedado

  const screens = document.querySelectorAll(".screen");
  const showScreen = (id) => {
    screens.forEach(screen => screen.classList.remove("active"));
    screens.forEach(screen => screen.classList.add("hidden"));
    const targetScreen = document.getElementById(id);
    targetScreen.classList.remove("hidden");
    targetScreen.classList.add("active");
  };

  // Navegar entre telas
  document.querySelectorAll(".navigate-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.target;
      showScreen(target);
    });
  });

  document.querySelectorAll(".back-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.target;
      showScreen(target);
    });
  });

  // Função para converter moedas
  document.getElementById("converter").addEventListener("click", async () => {
    const valor = document.getElementById("valor").value;
    const moedaDestino = document.getElementById("moeda-destino").value;
    const resultadoDiv = document.getElementById("resultado");

    if (!valor) {
      resultadoDiv.textContent = "Por favor, insira um valor para converter.";
      return;
    }

    try {
      const response = await fetch(`${API_URL}/convert?value=${valor}&to=${moedaDestino}`);
      if (!response.ok) {
        throw new Error("Erro na conversão.");
      }
      const data = await response.json();
      resultadoDiv.textContent = `Resultado: ${data.convertedValue}`;
    } catch (error) {
      resultadoDiv.textContent = "Erro ao conectar com o servidor. Verifique a conexão.";
    }
  });
});